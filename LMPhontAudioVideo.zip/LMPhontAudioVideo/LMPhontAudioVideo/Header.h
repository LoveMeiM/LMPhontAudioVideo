//
//  Header.h
//  LMPhontAudioVideo
//
//  Created by liubaojian on 16/11/8.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#ifndef Header_h
#define Header_h

#define HEIGHT                   [UIScreen mainScreen].bounds.size.height
#define WIDTH                    [UIScreen mainScreen].bounds.size.width
#define NEWX                     [UIScreen mainScreen].bounds.size.width/320
#define NEWY                     [UIScreen mainScreen].bounds.size.height/568
#define RECT(a,b,c,d,e)          CGRectMake(a*NEWX, e==0?b:b*NEWY, c*NEWX, d*NEWY)
#define Scale_X(a)               (a*NEWX)
#define Scale_Y(a)               (a*NEWY)
#define ViewlineColor ([UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1.00])
#define ORANGE_COLOR ([UIColor colorWithRed:252/255.0 green:133/255.0 blue:37/255.0 alpha:1.0f])


#endif /* Header_h */
