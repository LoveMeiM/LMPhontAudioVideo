//
//  ViewController.m
//  LMPhontAudioVideo
//
//  Created by liubaojian on 16/11/8.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "ViewController.h"
#import "FDAlertView.h"
#import "CustomAlertView.h"
#import <AVFoundation/AVFoundation.h>
#import "JFCompressionVideo.h"
#import "UIView+ShowSomething.h"
#import "Header.h"
#import "UIView+SDAutoLayout.h"



@interface ViewController ()
<CustomAlertViewclickDelegate,
UINavigationControllerDelegate,
UIImagePickerControllerDelegate>
{
    
    FDAlertView *alert;
    CustomAlertView *contentView;
}
@property (nonatomic,strong) UIImagePickerController *imagePickerController; //图片
@property (nonatomic,strong) UIImagePickerController *VideoPickerController; //录制视频
@property (nonatomic,strong) UIImagePickerController *ZYQPick;//选择视屏
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initBottowView];
    
}
//初始化底部视图
- (void)initBottowView
{
    UIView *bottowView = [[UIView alloc]init];
    bottowView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:bottowView];
    bottowView.sd_layout.leftSpaceToView(self.view,0).topSpaceToView(self.view,Scale_Y(90)).rightSpaceToView(self.view,0).heightIs(Scale_Y(60));
    
    [bottowView addlineView:0 :YES];
    
    NSArray *buttonTitle = @[@"图像",@"音频",@"视屏"];
    for (int i = 0; i<3; i++) {
        //线
        
        if (i!=2) {
            UIView *lineV=[[UIView alloc]init];
            lineV.backgroundColor = ViewlineColor;
            [bottowView addSubview:lineV];
            lineV.sd_layout.leftSpaceToView(bottowView,WIDTH/3*(i+1)).topSpaceToView(bottowView,0).widthIs(Scale_X(1)).bottomSpaceToView(bottowView,0);
        }
        
        UIButton *subMitButton = [self creatButtonWithAttribute:buttonTitle[i] :14 :[UIColor clearColor] :[UIColor blackColor]];
        [bottowView addSubview:subMitButton];
        subMitButton.sd_layout.leftSpaceToView(bottowView,WIDTH/3*i).topSpaceToView(bottowView,0).widthIs(WIDTH/3).bottomSpaceToView(bottowView,0);
        [subMitButton.titleLabel setFont:[UIFont systemFontOfSize:13]];
        subMitButton.tag = 200+i;
        [subMitButton addTarget:self action:@selector(bottowClick:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    
    [bottowView addlineView:59 :YES];
    
    alert = [[FDAlertView alloc] init];
    contentView = [[CustomAlertView alloc]initWithFrame:RECT(100, 100, 280, 400, 1)];
    contentView.layer.cornerRadius = 5;
    alert.contentView = contentView;
    contentView.mydelegate = self;
    
}

#pragma mark－－－－－－－－－－－－－－－－－－－底部视图的点击事件 delegate－－－－－－－－－－－－－－－－

- (void)bottowClick :(UIButton *)sender
{
    switch (sender.tag) {
        case 200://图片
        {
            contentView.bounds = RECT(0, 0, 240, 80, 1);
            alert.contentView = contentView;
            contentView.mystype = ForPhotoes;
            [alert show];
        }
            break;
        case 201: //音频
        {
            contentView.bounds = RECT(0, 0, 240, 80, 1);
            alert.contentView = contentView;
            contentView.mystype = ForAudio;
            [alert show];
        }
            break;
        case 202: //视屏
        {
            contentView.bounds = RECT(0, 0, 240, 80, 1);
            alert.contentView = contentView;
            contentView.mystype = ForVideo;
            [alert show];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark－－－－－－－－－－－－－－－－－－－CustomAlertViewclickDelegate delegate－－－－－－－－－－－－－－－－

- (void)actionOperate:(ActionType)type
{
    
    [alert hide];
    if (type == SELPhotoes) {
        UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
        imagePickerController.delegate = self;
        imagePickerController.allowsEditing = YES;
        imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:imagePickerController animated:YES completion:nil];
        
    }else if (type == MakePhooes){
        
        if (![self checkCameraIsAvailable]) {
            return;
        };
        
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:picker animated:YES completion:nil];
        [self.imagePickerController takePicture];
        
    }else if (type == SELAudio){//选择本地音频文件
        
    }else if (type == MakeAudio){
        contentView.bounds =RECT(0, 0, 240, 290, 1);
        [contentView layoutSubviews];
        [alert show];
        contentView.mystype = AudioResult;
        //最后一步
        [contentView showForTableView:NO :nil];
    }else if (type == SELVideo){
        
        if (![self checkCameraIsAvailable]) {
            return;
        };
        [self presentViewController:self.ZYQPick animated:YES completion:NULL];
    }else if (type == MakeVideo){
        
        if (![self checkCameraIsAvailable]) {
            return;
        };
        [self presentViewController:self.VideoPickerController animated:YES completion:nil];
    }
    
}

- (void)actionResult:(resultType)type
{
    if (type == PhotoesSure) {
        
    }else if (type == AudioSure){
        
    } else if (type == VideoSure){
        
    }
    [alert hide];
}

//检查相机是否可以使用
- (BOOL)checkCameraIsAvailable
{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        UIAlertAction *suerAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        }];
        UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"相机不可用" preferredStyle:UIAlertControllerStyleAlert];
        [alertVC addAction:suerAction];
        [self presentViewController:alertVC animated:YES completion:nil];
        
        return NO;
    }else{
        return YES;
    }
}


#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
    if ([mediaType isEqualToString:(NSString *)kUTTypeMovie])
    {
        
        NSLog(@"VIDEO....");
        NSURL *url = [info objectForKey:UIImagePickerControllerMediaURL];
        NSString *urlStr = [url path];
        if (UIVideoAtPathIsCompatibleWithSavedPhotosAlbum(urlStr))
        {
            UISaveVideoAtPathToSavedPhotosAlbum(urlStr, self, @selector(video:didFinishSavingWithError:contextInfo:), nil);
        }
        [picker dismissViewControllerAnimated:YES completion:nil];
        
   
//************************* 下面的方法是调用系统的方法 对视屏进行了压缩，压缩比 达到了  1:30  ******************************
        
//        NSURL *sourceURL = [info objectForKey:UIImagePickerControllerMediaURL];
//        NSLog(@"11%@",[NSString stringWithFormat:@"%f s", [self getVideoLength:sourceURL]]);
//        NSLog(@"22%@", [NSString stringWithFormat:@"%.2f kb", [self getFileSize:[sourceURL path]]]);
//        NSURL *newVideoUrl ; //一般.mp4
//        NSDateFormatter *formater = [[NSDateFormatter alloc] init];//用时间给文件全名，以免重复，在测试的时候其实可以判断文件是否存在若存在，则删除，重新生成文件即可
//        [formater setDateFormat:@"yyyy-MM-dd-HH:mm:ss"];
//        newVideoUrl = [NSURL fileURLWithPath:[NSHomeDirectory() stringByAppendingFormat:@"/Documents/output-%@.mp4", [formater stringFromDate:[NSDate date]]]] ;//这个是保存在app自己的沙盒路径里，后面可以选择是否在上传后删除掉。我建议删除掉，免得占空间。
//        [picker dismissViewControllerAnimated:YES completion:nil];
//        [self convertVideoQuailtyWithInputURL:sourceURL outputURL:newVideoUrl completeHandler:nil];
//        
   //***************************************************************
        
    }else
    {
        UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
        //NSData *imageData = UIImageJPEGRepresentation(currentImage, 1);
        
        contentView.bounds =RECT(0, 0, 240, 290, 1);
        [contentView layoutSubviews];
        [alert show];
        contentView.mystype = PhotoesResult;
        //最后一步
        [contentView showForTableView:NO :chosenImage];
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:NULL];
}


-(UIImagePickerController *)VideoPickerController
{
    if (!_VideoPickerController)
    {
        _VideoPickerController = [[UIImagePickerController alloc] init];
        _VideoPickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
        _VideoPickerController.cameraDevice = UIImagePickerControllerCameraDeviceRear;
        
        
        _VideoPickerController.mediaTypes = @[(NSString *)kUTTypeMovie];
        _VideoPickerController.videoQuality = UIImagePickerControllerQualityTypeIFrame1280x720;
        _VideoPickerController.cameraCaptureMode = UIImagePickerControllerCameraCaptureModeVideo;
        
        
        _VideoPickerController.allowsEditing = YES;
        _VideoPickerController.delegate = self;
    }
    
    return _VideoPickerController;
}

- (UIImagePickerController *)ZYQPick{
    if (!_ZYQPick)
    {
        _ZYQPick = [[UIImagePickerController alloc] init];
        _ZYQPick.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;//sourcetype有三种分别是camera，photoLibrary和photoAlbum
        NSArray *availableMedia = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera];//Camera所支持的Media格式都有哪些,共有两个分别是@"public.image",@"public.movie"
        _ZYQPick.mediaTypes = [NSArray arrayWithObject:availableMedia[1]];//设置媒体类型为public.movie
        _ZYQPick.delegate = self;//设置委托
    }
    
    return _ZYQPick;
}

-(void)video:(NSString *)videoPath didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    if (error)
    {
        NSLog(@"保存视频过程中发生错误，错误信息:%@",error.localizedDescription);
    }else
    {
        NSLog(@"视频保存成功。。。");
        //视频录制完之后自动播放
        
        NSData *data = [[NSData alloc]initWithContentsOfFile:videoPath];
        CGFloat jj = data.length/1024;
        CGFloat fileSize = [self getVideoLength:[NSURL URLWithString:videoPath]];
        
        
        contentView.bounds =RECT(0, 0, 240, 290, 1);
        [contentView layoutSubviews];
        [alert show];
        contentView.mystype = VideoResult;
        //最后一步
        [contentView showForTableView:NO :videoPath];
    }
}
//此方法可以获取视频文件的时长。
- (CGFloat) getFileSize:(NSString *)path
{
    NSLog(@"%@",path);
    NSFileManager *fileManager = [NSFileManager defaultManager];
    float filesize = -1.0;
    if ([fileManager fileExistsAtPath:path]) {
        NSDictionary *fileDic = [fileManager attributesOfItemAtPath:path error:nil];//获取文件的属性
        unsigned long long size = [[fileDic objectForKey:NSFileSize] longLongValue];
        filesize = 1.0*size/1024;
    }else{
        NSLog(@"找不到文件");
    }
    return filesize;
}//此方法可以获取视频文件的时长。
- (CGFloat) getVideoLength:(NSURL *)URL
{
    
    AVURLAsset *avUrl = [AVURLAsset assetWithURL:URL];
    CMTime time = [avUrl duration];
    int second = ceil(time.value/time.timescale);
    return second;
}


// 视屏压缩方法
- (void) convertVideoQuailtyWithInputURL:(NSURL*)inputURL
                               outputURL:(NSURL*)outputURL
                         completeHandler:(void (^)(AVAssetExportSession*))handler
{
    AVURLAsset *avAsset = [AVURLAsset URLAssetWithURL:inputURL options:nil];
    
    AVAssetExportSession *exportSession = [[AVAssetExportSession alloc] initWithAsset:avAsset presetName:AVAssetExportPresetMediumQuality];
    //  NSLog(resultPath);
    exportSession.outputURL = outputURL;
    exportSession.outputFileType = AVFileTypeMPEG4;
    exportSession.shouldOptimizeForNetworkUse= YES;
    [exportSession exportAsynchronouslyWithCompletionHandler:^(void)
     {
         switch (exportSession.status) {
             case AVAssetExportSessionStatusCancelled:
                 NSLog(@"AVAssetExportSessionStatusCancelled");
                 break;
             case AVAssetExportSessionStatusUnknown:
                 NSLog(@"AVAssetExportSessionStatusUnknown");
                 break;
             case AVAssetExportSessionStatusWaiting:
                 NSLog(@"AVAssetExportSessionStatusWaiting");
                 break;
             case AVAssetExportSessionStatusExporting:
                 NSLog(@"AVAssetExportSessionStatusExporting");
                 break;
             case AVAssetExportSessionStatusCompleted:
                 NSLog(@"AVAssetExportSessionStatusCompleted");
                 NSLog(@"%@",[NSString stringWithFormat:@"33 %f s", [self getVideoLength:outputURL]]);
                 NSLog(@"%@", [NSString stringWithFormat:@"44 %.2f kb", [self getFileSize:[outputURL path]]]);
                 
                 //UISaveVideoAtPathToSavedPhotosAlbum([outputURL path], self, nil, NULL);//这个是保存到手机相册
                 
                 // [self alertUploadVideo:outputURL];
                 break;
             case AVAssetExportSessionStatusFailed:
                 NSLog(@"AVAssetExportSessionStatusFailed");
                 break;
         }
         
     }];
}


- (UIButton *)creatButtonWithAttribute :(NSString *)titleText
                                       :(NSInteger )font
                                       :(UIColor *)bgColor
                                       :(UIColor *)textColor
{
    UIButton *button=[[UIButton alloc]initWithFrame:CGRectZero];
    [button setBackgroundColor:bgColor];
    [button setTitle:titleText forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont systemFontOfSize:font]];
    [button setTitleColor:textColor forState:UIControlStateNormal];
    return button;
}

@end
