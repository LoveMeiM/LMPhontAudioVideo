//
//  UIView+ShowSomething.h
//  BossTreasure
//
//  Created by liubaojian on 16/9/14.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ShowSomething)

- (void)addlineView :(CGFloat)yValue :(BOOL)zoreStart;

@end
