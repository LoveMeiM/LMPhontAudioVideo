//
//  WTRecorder.m
//  WTEnjoyVoice
//
//  Created by 隋文涛 on 16/5/26.
//  Copyright © 2016年 wintelsui. All rights reserved.
//

#import "WTRecorder.h"
#import "math.h"
#import "UIView+SDAutoLayout.h"
#import "Header.h"

@implementation WTRecorder
@synthesize audioRecorder;
@synthesize audioPlayer;
@synthesize audioPath;

@synthesize isAllowUseMIC;
@synthesize isRecording;
@synthesize isRecordedWave;

- (void)awakeFromNib
{
    [self setup];
    [self checkRecord];
    [self performSelector:@selector(setupView)
               withObject:nil afterDelay:0];
}
- (void)setupView{

    actionView = [[UIView alloc] init];
    [actionView setFrame:CGRectMake(0,  0, self.frame.size.width, self.frame.size.height)];
    [actionView setBackgroundColor:[UIColor whiteColor]];
    [self addSubview:actionView];
    
    
    recordButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [recordButton setImage:[UIImage imageNamed:@"iconRecorderStart"] forState:UIControlStateNormal];
    [recordButton setImage:[UIImage imageNamed:@"iconRecorderStop"] forState:UIControlStateSelected];
    [recordButton addTarget:self action:@selector(clickedRecorderButton:) forControlEvents:UIControlEventTouchUpInside];
    [actionView addSubview:recordButton];
    recordButton.sd_layout.centerXEqualToView(actionView).topSpaceToView(actionView,Scale_Y(20)). widthIs(Scale_X(70)).heightIs(Scale_Y(70));
    
    
    timeLabel = [[UILabel alloc] init];
    timeLabel.backgroundColor = [UIColor redColor];
    [timeLabel setBackgroundColor:[UIColor clearColor]];
    [timeLabel setTextColor:[UIColor blackColor]];
    [timeLabel setTextAlignment:NSTextAlignmentCenter];
    [timeLabel setFont:[UIFont systemFontOfSize:16.0f]];
    [timeLabel setText:@""];
    [actionView addSubview:timeLabel];
    timeLabel.sd_layout.centerXEqualToView(actionView).topSpaceToView(recordButton,Scale_Y(10)). widthIs(Scale_X(100)).heightIs(Scale_Y(20));
    
    
    playButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [playButton setTitle:@"播放" forState:UIControlStateNormal];
    [playButton setTitle:@"停止" forState:UIControlStateSelected];
    [playButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [playButton.layer setBorderWidth:1];
    [playButton.layer setBorderColor:[UIColor blackColor].CGColor];
    [playButton addTarget:self action:@selector(clickedVoicePlay:) forControlEvents:UIControlEventTouchUpInside];
    [actionView addSubview:playButton];
    playButton.sd_layout.centerXEqualToView(actionView).bottomSpaceToView(actionView,Scale_Y(20)). widthIs(Scale_X(70)).heightIs(Scale_Y(30));
    
    self.backgroundColor = [UIColor whiteColor];
    
    
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self)
    {
       [self setup];
       [self setupView];
    }
    return self;
}

- (void)setup {
    intervalTime = 0.025;
    sampleWidth = 0.5;
}

- (void)restRecord{
//    [waveView.samples removeAllObjects];
//    [waveView setNeedsDisplay];
    
    [timeLabel setText:@"0"];
}

- (BOOL)checkRecord{
    if ([self canRecord]) {
        isAllowUseMIC = YES;
    }else{
        isAllowUseMIC = NO;
    }
    return isAllowUseMIC;
}

- (void)startRecord
{
    if (isRecording){
        return;
    }
    if (isRecordedWave) {
        [self restRecord];
    }
    
    if (isAllowUseMIC) {
        isRecording = YES;
        NSLog(@"startRecord");
        audioRecorder = nil;
        isRecordedWave = YES;
        
        // Init audio with record capability
        AVAudioSession *audioSession = [AVAudioSession sharedInstance];
        [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
        
        NSDictionary *recordSettings=[NSDictionary dictionaryWithObjectsAndKeys:
                                      [NSNumber numberWithFloat:8000],AVSampleRateKey,
                                      [NSNumber numberWithInt:kAudioFormatLinearPCM],AVFormatIDKey,
                                      [NSNumber numberWithInt:1],AVNumberOfChannelsKey,
                                      [NSNumber numberWithInt:16],AVLinearPCMBitDepthKey,
                                      [NSNumber numberWithBool:NO],AVLinearPCMIsBigEndianKey,
                                      [NSNumber numberWithBool:NO],AVLinearPCMIsFloatKey,
                                      nil];
        
        audioPath = [self FilePathInLibraryWithName:@"Caches/UserRecordTemp.wav"];
        NSURL *url = [NSURL fileURLWithPath:audioPath];
        
        NSError *error = nil;
        audioRecorder = [[ AVAudioRecorder alloc] initWithURL:url settings:recordSettings error:&error];
        [audioRecorder setMeteringEnabled:YES];
        if ([audioRecorder prepareToRecord] == YES){
            [audioRecorder record];
        }else {
            int errorCode = CFSwapInt32HostToBig ((int)[error code]);
            NSLog(@"Error: %@ [%4.4s])" , [error localizedDescription], (char*)&errorCode);
        }
        if (audioRecorder.isRecording) {
            NSLog(@"recording");
            [self initTimer];
        }
    }
}

-(void)stopRecord
{
    NSLog(@"stopRecord");
    [audioRecorder stop];
    audioRecorder=nil;
    
    isRecording = NO;
    
    [RecordingTimer invalidate];
    RecordingTimer = nil;
}

-(void)initTimer
{
    [RecordingTimer invalidate];
    RecordingTimer = nil;
    //定时器
    RecordingTimer = [NSTimer scheduledTimerWithTimeInterval:intervalTime
                                                      target:self
                                                    selector:@selector(handleMaxRecordingTimer:)
                                                    userInfo:nil
                                                     repeats:YES];
    [RecordingTimer fire];
}

//刷新界面
-(void)handleMaxRecordingTimer:(NSTimer *)theTimer
{
    if (audioRecorder && audioRecorder.isRecording) {
        [audioRecorder updateMeters];
        float peakPowerForChannel = [audioRecorder peakPowerForChannel:0];
        float peakPower = pow(10, (0.05 * peakPowerForChannel));
        NSLog(@"peakPower   :%lf   from :%lf",peakPower,peakPowerForChannel);
        
        float time = audioRecorder.currentTime;
        NSInteger time2 = time * 100;
        NSInteger timeMin = time2 / 6000;
        NSInteger timeSe = time2 % 6000;
        
        NSString *timeString;
        if (timeMin == 0) {
             timeString = [NSString stringWithFormat:@"%0.2f\"",(timeSe / 100.00)];
        }else{
            timeString = [NSString stringWithFormat:@"%ld' %0.1f\"",timeMin,(timeSe / 100.00)];
        }
        [timeLabel setText:timeString];
    }
}

- (void)drawRect:(CGRect)rect{
    [[UIColor blackColor] set];
    UIRectFill(self.bounds);
}


- (BOOL)canRecord
{
    __block BOOL bCanRecord = YES;
    if ([[UIDevice currentDevice].systemVersion doubleValue] > 6.9)
    {
        AVAudioSession *audioSession = [AVAudioSession sharedInstance];
        if ([audioSession respondsToSelector:@selector(requestRecordPermission:)]) {
            [audioSession performSelector:@selector(requestRecordPermission:) withObject:^(BOOL granted) {
                if (granted) {
                    bCanRecord = YES;
                } else {
                    bCanRecord = NO;
                }
            }];
        }
    }
    return bCanRecord;
}


- (IBAction)clickedRecorderButton:(id)sender {
    UIButton *bt = (UIButton *)sender;
    [self stopPlaying];
    if (self.isAllowUseMIC) {
        if (bt.isSelected) {
            [bt setSelected:NO];
            [self stopRecord];
        }else{
            [bt setSelected:YES];
            [self startRecord];
        }
    }
}

#pragma mark 播放

- (IBAction)clickedVoicePlay:(id)sender {
    if (audioPlayer != nil && audioPlayer.isPlaying) {
        [playButton setSelected:NO];
        [self stopPlaying];
    }else{
        if (self.isRecordedWave && !self.isRecording) {
            [playButton setSelected:YES];
            [self playRecordingWithPath:self.audioPath];
        }
    }
}


-(void) playRecordingWithPath:(NSString *)RecordPath{
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    [audioSession setCategory:AVAudioSessionCategoryPlayback error:nil];
    
    NSURL *url;
    url = [NSURL fileURLWithPath:RecordPath];
    NSError *error;
    audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
    
    if (error != nil){
        [self stopPlaying];
    }else{
        audioPlayer.numberOfLoops = 0;
        audioPlayer.delegate = self;
        [audioPlayer play];
        NSLog(@"playing");
    }
}

-(void) stopPlaying
{
    NSLog(@"stopPlaying");
    [audioPlayer stop];
    audioPlayer = nil;
}

#pragma mark－－－－－－－－－－－－－－－－－－－AVAudioPlayerDelegate delegate－－－－－－－－－－－－－－－－

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag{
    [playButton setSelected:NO];
    audioPlayer = nil;
}

- (NSString *)FilePathInLibraryWithName:(NSString *)name{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
    NSString *LibraryDirectory = [paths objectAtIndex:0];
    return [LibraryDirectory stringByAppendingPathComponent:name];
}
@end
