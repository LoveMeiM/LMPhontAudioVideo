//
//  AppDelegate.h
//  LMPhontAudioVideo
//
//  Created by liubaojian on 16/11/8.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

