//
//  CustomAlertView.m
//  BossTreasure
//
//  Created by liubaojian on 16/6/29.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "CustomAlertView.h"
#import "UIView+SDAutoLayout.h"
#import "UITableView+SDAutoTableViewCellHeight.h"
#import "Header.h"


@implementation CustomAlertView


- (instancetype)initWithFrame:(CGRect)frame ;
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];
        _dataArray = [[NSMutableArray alloc]initWithCapacity:0];
        self.clipsToBounds = YES;
        
        //底部的按钮
        
        leftButton = [self creatButtonWithAttribute:@"" :11 :[UIColor whiteColor] :ORANGE_COLOR];
        [self addSubview:leftButton];
        leftButton.sd_layout.leftSpaceToView(self,Scale_X(30)).bottomSpaceToView(self,Scale_Y(20)).widthIs(Scale_X(70)).heightIs(Scale_Y(30));
        [leftButton addTarget:self action:@selector(leftClick) forControlEvents:UIControlEventTouchUpInside];
        [leftButton.layer setBorderWidth:1];
        [leftButton.layer setBorderColor:ORANGE_COLOR.CGColor];
        
        
        rightButton = [self creatButtonWithAttribute:@"" :11 :[UIColor whiteColor] :[UIColor blackColor]];
        [self addSubview:rightButton];
        [rightButton addTarget:self action:@selector(rightClick ) forControlEvents:UIControlEventTouchUpInside];
        rightButton.sd_layout.rightSpaceToView(self,Scale_X(30)).bottomSpaceToView(self,Scale_Y(20)).widthIs(Scale_X(70)).heightIs(Scale_Y(30));
        [rightButton.layer setBorderWidth:1];
        [rightButton.layer setBorderColor:[UIColor blackColor].CGColor];
        
    }
    return self;
}
- (void)setMystype:(ForStyle)mystype
{
    _mystype = mystype;
    rightButton.hidden = NO;
    leftButton.sd_layout.leftSpaceToView(self,Scale_X(30)).bottomSpaceToView(self,Scale_Y(20)).widthIs(Scale_X(70)).heightIs(Scale_Y(30));
    
    if (_mystype == ForPhotoes) {
        [leftButton setTitle:@"相机" forState:UIControlStateNormal];
        [rightButton setTitle:@"相册" forState:UIControlStateNormal];
    }else if (_mystype == ForAudio){
        [leftButton setTitle:@"录音" forState:UIControlStateNormal];
        leftButton.sd_layout.leftSpaceToView(self,Scale_X(30)).bottomSpaceToView(self,Scale_Y(20)).widthIs(Scale_X(180)).heightIs(Scale_Y(30));
        rightButton.hidden = YES;
    }else if (_mystype == ForVideo){
        [leftButton setTitle:@"录像" forState:UIControlStateNormal];
        [rightButton setTitle:@"选择视频" forState:UIControlStateNormal];
    }else {
        [leftButton setTitle:@"确定" forState:UIControlStateNormal];
        [rightButton setTitle:@"取消" forState:UIControlStateNormal];
    }
    
    [_tableViewBgView removeFromSuperview];
    [_resultView removeFromSuperview];
}


- (UIView *)tableViewBgView
{
    if (!_tableViewBgView) {
        _tableViewBgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height-50)];
        _tableViewBgView.backgroundColor = [UIColor clearColor];
        

    }
    return _tableViewBgView;
}
- (UIView *)resultView
{
    if (!_resultView) {
        _resultView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height-Scale_Y(60))];
        _resultView.backgroundColor = [UIColor clearColor];
    
        imageView =  [self creatImageWithAttribute:@"test"];
        imageView.backgroundColor = [UIColor clearColor];
        [_resultView addSubview:imageView];
        imageView.sd_layout.leftSpaceToView(_resultView,Scale_X(10)).topSpaceToView(_resultView,Scale_Y(10)).rightSpaceToView(_resultView,Scale_X(10)).bottomSpaceToView(_resultView,Scale_X(10));
        
        //音频
        avdioStr = [[WTRecorder alloc]initWithFrame:CGRectMake(Scale_X(10), Scale_Y(10), _resultView.width-Scale_X(20), _resultView.height-Scale_X(20))];
        [avdioStr checkRecord];
        [_resultView addSubview:avdioStr];
        
        //视频
       
        self.playerLayer = [[AVPlayerLayer alloc]init];
        self.playerLayer.frame = CGRectMake(Scale_X(10), Scale_Y(10), _resultView.width-Scale_X(20), _resultView.height-Scale_X(20));
        [_resultView.layer addSublayer:self.playerLayer];
       
    }
    return _resultView;
}

- (void)showForTableView :(BOOL)forTableView :(id)data
{
    if (forTableView) {
        _dataArray = [NSMutableArray arrayWithArray:(NSArray *)data];
        [Tb reloadData];
        [self.resultView removeFromSuperview];
        [self addSubview:self.tableViewBgView];
    }
    else{

        [self.tableViewBgView removeFromSuperview];
        [self addSubview:self.resultView];

        if (self.mystype == AudioResult) {
            imageView.hidden = YES;
            self.playerLayer.hidden = YES;
            avdioStr.hidden = NO;
            
        }else if (self.mystype == PhotoesResult){
            avdioStr.hidden = YES;
            self.playerLayer.hidden = YES;
            imageView.hidden = NO;
            imageView.image = data;
        }else if (self.mystype == VideoResult)
        {
            avdioStr.hidden = YES;
            imageView.hidden = YES;
            self.playerLayer.hidden = NO;
            
            //播放设置
            NSURL *url = [NSURL fileURLWithPath:data];
            AVPlayer *myPlayer = [AVPlayer playerWithURL:url];
            _playerLayer.player = myPlayer;
            [myPlayer play];
        }
    }
}

- (void)leftClick
{
    if (self.mystype == ForPhotoes) {
        [self.mydelegate actionOperate:MakePhooes];
    }else if (self.mystype == ForAudio){
       [self.mydelegate actionOperate:MakeAudio];
    }else if (self.mystype == ForVideo){
       [self.mydelegate actionOperate:MakeVideo];
    }else if (self.mystype == PhotoesResult){
       [self.mydelegate actionResult:PhotoesSure];
    }else if (self.mystype == AudioResult){
        [self.mydelegate actionResult:AudioSure];
    }else if (self.mystype == VideoResult){
        [self.mydelegate actionResult:VideoSure];
    }
}
- (void)rightClick
{
    if (self.mystype == ForPhotoes) {
        [self.mydelegate actionOperate:SELPhotoes];
    }else if (self.mystype == ForAudio){
        [self.mydelegate actionOperate:SELAudio];
    }else if (self.mystype == ForVideo){
        [self.mydelegate actionOperate:SELVideo];
    }else if (self.mystype == PhotoesResult){
        [self.mydelegate actionResult:PhotoesCancel];
    }else if (self.mystype == AudioResult){
        [self.mydelegate actionResult:AudioCancel];
    }else if (self.mystype == VideoResult){
        [self.mydelegate actionResult:VideoCancel];
    }
}


- (UIButton *)creatButtonWithAttribute :(NSString *)titleText
                                       :(NSInteger )font
                                       :(UIColor *)bgColor
                                       :(UIColor *)textColor
{
    UIButton *button=[[UIButton alloc]initWithFrame:CGRectZero];
    [button setBackgroundColor:bgColor];
    [button setTitle:titleText forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont systemFontOfSize:font]];
    [button setTitleColor:textColor forState:UIControlStateNormal];
    return button;
}
- (UIImageView *)creatImageWithAttribute:(NSString *)imageName
{
    UIImageView *ImageV =[[UIImageView alloc] initWithFrame:CGRectZero];
    if (imageName.length>0) {
        ImageV.image = [UIImage  imageNamed:imageName];
    }
    ImageV.backgroundColor = [UIColor clearColor];
    return ImageV;
}

@end
