//
//  CustomAlertView.h
//  BossTreasure
//
//  Created by liubaojian on 16/6/29.
//  Copyright © 2016年 liubaojian. All rights reserved.
//


/*
 ******************************************
 *
 *QQ:3095167957
 *
 *
 *
 ******************************************
 */


#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <AVFoundation/AVFoundation.h>
#import "WTRecorder.h"


typedef enum {
    ForPhotoes = 0, //图片
    ForAudio  = 1,  //音频
    ForVideo  = 2,  //视频
    PhotoesResult = 3,
    AudioResult = 4,
    VideoResult = 5,
    
} ForStyle;


typedef enum {
    SELPhotoes = 0,
    MakePhooes  = 1,
    SELAudio = 2,
    MakeAudio  = 3,
    SELVideo = 4,
    MakeVideo  = 5,
    
} ActionType;

typedef enum {
    PhotoesSure = 0,
    PhotoesCancel  = 1,
    AudioSure = 2,
    AudioCancel  = 3,
    VideoSure = 4,
    VideoCancel  = 5,
    
} resultType ;

@protocol CustomAlertViewclickDelegate <NSObject>

@optional
- (void)actionOperate :(ActionType)type;
- (void)actionResult :(resultType)type;


@end
@interface CustomAlertView : UIView
<UITableViewDelegate,UITableViewDataSource>
{
    UITableView  *Tb;
    NSMutableArray *_dataArray;
    
    UIButton *leftButton;
    UIButton *rightButton;
    
    UIImageView *imageView;
    WTRecorder *avdioStr;
}

@property (assign,nonatomic) ForStyle mystype;
@property(strong,nonatomic)UIView *tableViewBgView;
@property(strong,nonatomic)UIView *resultView;
@property (nonatomic,strong)AVPlayerLayer *playerLayer;//播放器layer，用于录制完视频后播放视频

@property(assign,nonatomic)id <CustomAlertViewclickDelegate>mydelegate;

- (instancetype)initWithFrame:(CGRect)frame ;
- (void)showForTableView :(BOOL)forTableView :(id)data;


@end
