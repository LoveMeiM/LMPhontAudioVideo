//
//  UIView+ShowSomething.m
//  BossTreasure
//
//  Created by liubaojian on 16/9/14.
//  Copyright © 2016年 liubaojian. All rights reserved.
//

#import "UIView+ShowSomething.h"
#import "UIView+SDAutoLayout.h"
#import "Header.h"

@implementation UIView (ShowSomething)

- (void)addlineView :(CGFloat)yValue :(BOOL)zoreStart;
{
    //线
    UIView *lineV=[[UIView alloc]init];
    lineV.backgroundColor = ViewlineColor;
    [self addSubview:lineV];
    lineV.sd_layout.leftSpaceToView(self,zoreStart?0:Scale_X(20)).topSpaceToView(self,Scale_Y((yValue))).rightSpaceToView(self,zoreStart?0:Scale_X(20)).heightIs(Scale_X(1));
}

@end
